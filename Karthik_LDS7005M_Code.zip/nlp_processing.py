# Importing the required PySpark libraries for data processing and transformation
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col,
    lower,
    regexp_replace,
    length,
    when,
    year,
    to_timestamp
)

# Creating the Spark session for distributed big data processing
# The application name is configured for easier identification within AWS EMR logs
spark = SparkSession.builder \
    .appName("Karthik Yelp NLP Processing") \
    .getOrCreate()

# Defining the input path where the raw Yelp JSON dataset is stored in Amazon S3
input_path = "s3://karthik-global-news-nlp/raw/yelp_academic_dataset_review.json"

# Defining the output path for storing the processed Parquet files
output_path = "s3://karthik-global-news-nlp/processed/yelp_reviews_parquet/"

# Loading the raw JSON dataset into a Spark DataFrame
# Spark automatically infers the schema from the JSON structure
df = spark.read.json(input_path)

# Performing NLP-oriented preprocessing and feature engineering
clean_df = (
    df.dropna(subset=["text", "stars", "date"])  # Removing records with missing critical fields
      .dropDuplicates(["review_id"])             # Eliminating duplicate reviews using review_id
     
      # Converting review text into lowercase for normalization
      .withColumn("clean_text", lower(col("text")))
     
      # Removing punctuation marks, digits, and special characters using regular expressions
      .withColumn(
          "clean_text",
          regexp_replace(col("clean_text"), "[^a-zA-Z\\s]", "")
      )
     
      # Calculating the total number of characters in each review
      .withColumn("review_length", length(col("text")))
     
      # Creating sentiment labels based on star ratings
      # Reviews with 4 or 5 stars are classified as positive
      # Reviews with 1 or 2 stars are classified as negative
      # Reviews with 3 stars are classified as neutral
      .withColumn(
          "sentiment",
          when(col("stars") >= 4, "positive")
          .when(col("stars") <= 2, "negative")
          .otherwise("neutral")
      )
     
      # Converting the review date into timestamp format
      .withColumn("review_timestamp", to_timestamp(col("date")))
     
      # Extracting the review year for partition-based storage optimisation
      .withColumn("review_year", year(col("review_timestamp")))
)

# Selecting the final columns required for downstream analytics and machine learning
# The processed dataset is stored in Parquet format for efficient querying and compression
clean_df.select(
    "review_id",
    "user_id",
    "business_id",
    "stars",
    "sentiment",
    "review_year",
    "review_length",
    "clean_text"
).write \
 .mode("overwrite") \
 .partitionBy("review_year") \
 .parquet(output_path)

# Displaying execution summary information
print("Yelp NLP preprocessing completed successfully.")
print("Raw records:", df.count())
print("Processed records:", clean_df.count())

# Stopping the Spark session after successful execution
spark.stop()