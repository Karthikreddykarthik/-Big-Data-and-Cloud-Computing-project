# Importing the required PySpark SQL and Machine Learning libraries
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col,
    lower,
    regexp_replace,
    when,
    year,
    to_timestamp,
    length
)

# Importing Spark ML components for NLP feature engineering and classification
from pyspark.ml.feature import (
    Tokenizer,
    StopWordsRemover,
    HashingTF,
    IDF,
    StringIndexer
)

from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import MulticlassClassificationEvaluator

# Creating the Spark session for distributed machine learning processing
# The application name will appear in AWS EMR Serverless monitoring logs
spark = SparkSession.builder \
    .appName("Karthik Yelp ML Sentiment Classification") \
    .getOrCreate()

# Defining the raw input dataset path stored in Amazon S3
input_path = "s3://karthik-global-news-nlp/raw/yelp_academic_dataset_review.json"

# Output location for storing prediction results
ml_output_path = "s3://karthik-global-news-nlp/output/predictions/"

# Output location for storing machine learning evaluation metrics
metrics_output_path = "s3://karthik-global-news-nlp/output/metrics/"

# Loading the Yelp JSON dataset into a Spark DataFrame
df = spark.read.json(input_path)

# Limiting the dataset size for faster model training within the AWS student lab environment
# This reduces computational overhead while still maintaining sufficient data for analysis
df = df.limit(300000)

# Performing data cleaning and NLP preprocessing
clean_df = (
    df.dropna(subset=["text", "stars", "date"])  # Removing incomplete records
      .dropDuplicates(["review_id"])             # Removing duplicate reviews

      # Converting all review text into lowercase for standardization
      .withColumn("clean_text", lower(col("text")))

      # Removing punctuation marks, digits, and special characters
      .withColumn(
          "clean_text",
          regexp_replace(col("clean_text"), "[^a-zA-Z\\s]", "")
      )

      # Calculating review length for additional analytical features
      .withColumn("review_length", length(col("text")))

      # Converting the review date into timestamp format
      .withColumn("review_timestamp", to_timestamp(col("date")))

      # Extracting the review year from the timestamp
      .withColumn("review_year", year(col("review_timestamp")))

      # Rule-based sentiment labeling using Yelp star ratings
      .withColumn(
          "sentiment",
          when(col("stars") >= 4, "positive")
          .when(col("stars") <= 2, "negative")
          .otherwise("neutral")
      )
)

# Tokenizing the cleaned review text into individual words
tokenizer = Tokenizer(
    inputCol="clean_text",
    outputCol="tokens"
)

tokenized_df = tokenizer.transform(clean_df)

# Removing common English stopwords to improve NLP quality
remover = StopWordsRemover(
    inputCol="tokens",
    outputCol="filtered_tokens"
)

filtered_df = remover.transform(tokenized_df)

# Converting tokenized text into numerical term-frequency vectors
# HashingTF is used because it is scalable and memory efficient for big data processing
hashing_tf = HashingTF(
    inputCol="filtered_tokens",
    outputCol="raw_features",
    numFeatures=10000
)

featurized_df = hashing_tf.transform(filtered_df)

# Applying TF-IDF weighting to improve feature importance representation
idf = IDF(
    inputCol="raw_features",
    outputCol="features"
)

idf_model = idf.fit(featurized_df)

tfidf_df = idf_model.transform(featurized_df)

# Encoding categorical sentiment labels into numerical machine learning labels
indexer = StringIndexer(
    inputCol="sentiment",
    outputCol="label"
)

indexed_df = indexer.fit(tfidf_df).transform(tfidf_df)

# Selecting the final columns required for model training
ml_df = indexed_df.select(
    "review_id",
    "stars",
    "sentiment",
    "label",
    "features",
    "review_year",
    "review_length"
).dropna()

# Splitting the dataset into training and testing subsets
# 80% for training and 20% for evaluation
train_data, test_data = ml_df.randomSplit([0.8, 0.2], seed=42)

# Creating the Logistic Regression classification model
# Logistic Regression is suitable for large-scale text classification problems
lr = LogisticRegression(
    featuresCol="features",
    labelCol="label",
    maxIter=10
)

# Training the machine learning model
model = lr.fit(train_data)

# Generating sentiment predictions on the test dataset
predictions = model.transform(test_data)

# Evaluating model accuracy
accuracy_evaluator = MulticlassClassificationEvaluator(
    labelCol="label",
    predictionCol="prediction",
    metricName="accuracy"
)

# Evaluating the F1 Score for balanced classification performance
f1_evaluator = MulticlassClassificationEvaluator(
    labelCol="label",
    predictionCol="prediction",
    metricName="f1"
)

# Calculating evaluation metrics
accuracy = accuracy_evaluator.evaluate(predictions)
f1_score = f1_evaluator.evaluate(predictions)

# Displaying execution summary and model performance
print("Machine Learning completed successfully.")
print("Training records:", train_data.count())
print("Testing records:", test_data.count())
print("Accuracy:", accuracy)
print("F1 Score:", f1_score)

# Saving prediction outputs in Parquet format for scalable analytics
predictions.select(
    "review_id",
    "stars",
    "sentiment",
    "label",
    "prediction",
    "probability",
    "review_year",
    "review_length"
).write \
 .mode("overwrite") \
 .parquet(ml_output_path)

# Creating a metrics DataFrame to store model evaluation results
metrics_df = spark.createDataFrame(
    [("Logistic Regression", accuracy, f1_score)],
    ["model", "accuracy", "f1_score"]
)

# Saving evaluation metrics as CSV format
metrics_df.write \
    .mode("overwrite") \
    .csv(metrics_output_path, header=True)

# Displaying a sample of prediction results
predictions.select(
    "review_id",
    "stars",
    "sentiment",
    "label",
    "prediction",
    "probability"
).show(20, truncate=False)

# Stopping the Spark session after successful completion
spark.stop()