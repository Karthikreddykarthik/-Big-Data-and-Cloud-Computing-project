# Query 1 — View Dataset

SELECT * 
FROM global_news
LIMIT 10;

# Query 2

SELECT COUNT(*)
FROM yelp_raw;

# Query 3

SELECT stars,
COUNT(*) AS total_reviews
FROM yelp_raw
GROUP BY stars
ORDER BY total_reviews DESC;

# Query 4

SELECT user_id,
COUNT(*) AS total_reviews
FROM yelp_raw
GROUP BY user_id
ORDER BY total reviews DESC
LIMIT 10;

# Query 5

SELECT substr(date,1,4) AS review_year,
COUNT(*) AS total_reviews
FROM yelp_raw
GROUP BY substr(date,1,4)
ORDER BY review_year;

# Query 6

SELECT AVG(stars) AS average_rating
FROM yelp_raw;

# Query 7

SELECT LENGTH(text) AS review_length,
text

FROM yelp_raw
ORDER BY review_length DESC
LIMIT 5;

# Query 8

SELECT useful,
stars,
text
FROM yelp_raw
ORDER BY useful DESC
LIMIT 10;

--------------------------
### Run Optimized Queries
-----------------------------

# Query 1 — Review Trend by Year

SELECT review_year, COUNT(*) AS total_reviews
FROM processed_yelp_reviews_parquet
GROUP BY review_year
ORDER BY review_year;

# Query 2 — Sentiment Distribution

SELECT sentiment, COUNT(*) AS total_reviews
FROM processed_yelp_reviews_parquet
GROUP BY sentiment;

# Query 3 — Average Review Length

SELECT stars,
AVG(review_length) AS avg_review_length
FROM processed_yelp_reviews_parquet
GROUP BY stars
ORDER BY stars;


